![Discord](https://img.shields.io/discord/798014878018174976?style=flat-square)
![GitHub last commit](https://img.shields.io/github/last-commit/averwhy/EconomyX?style=flat-square)
![GitHub top language](https://img.shields.io/github/languages/top/averwhy/EconomyX?color=3572a5&style=flat-square)
![GitHub issues](https://img.shields.io/github/issues/averwhy/EconomyX?style=flat-square)
![GitHub](https://img.shields.io/github/license/averwhy/EconomyX?style=flat-square)
![GitHub Repo stars](https://img.shields.io/github/stars/averwhy/EconomyX?color=e3b341&style=flat-square)
![Maintenance](https://img.shields.io/maintenance/yes/2022?style=flat-square)

# EconomyX
 A unique, global economy bot for Discord.

## Features
 - Simple currency system
 - Lots of commands to gain money
 - Daily lottery system
 - Stock and investment system
 - User profiles with customization
 - Opt-in system made with privacy in mind

### Note
I would **not** recommend hosting your own, since you can just invite the bot I'm hosting using this link: https://discord.com/api/oauth2/authorize?client_id=780480654277476352&permissions=0&scope=bot