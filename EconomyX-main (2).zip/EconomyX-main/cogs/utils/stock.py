class stock:
    def __init__(self) -> None:
        pass # TODO: write this class